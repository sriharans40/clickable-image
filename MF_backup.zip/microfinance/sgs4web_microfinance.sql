-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 02, 2015 at 07:00 PM
-- Server version: 5.5.42-cll
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sgs4web_microfinance`
--

-- --------------------------------------------------------

--
-- Table structure for table `mf_customer`
--

CREATE TABLE IF NOT EXISTS `mf_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lender_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(500) NOT NULL,
  `phone` varchar(500) NOT NULL,
  `picture` varchar(500) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=660007 ;

--
-- Dumping data for table `mf_customer`
--

INSERT INTO `mf_customer` (`id`, `lender_id`, `name`, `dob`, `address`, `phone`, `picture`, `status`) VALUES
(60000, 6, 'sqe', '2015-04-17', 'fg', '', '', 1),
(60001, 6, 'aaa', '0000-00-00', '', '', '', 1),
(60004, 6, 'bbbb', '0000-00-00', '', '', '', 1),
(60003, 6, 'ttt', '0000-00-00', '', '', '', 1),
(60002, 6, 'uuu', '0000-00-00', '', '', '', 1),
(60005, 6, 'test2', '2015-04-19', 'bangalore ', '9999999999', '', 1),
(660006, 66, 'vinoth', '2015-06-23', 'Bangalore', '9876543210', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mf_loan`
--

CREATE TABLE IF NOT EXISTS `mf_loan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `lender_id` int(11) NOT NULL,
  `loan_amount` int(11) NOT NULL,
  `interest` varchar(500) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `daily_amount` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `payback_amount` int(11) NOT NULL,
  `balance_amount` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=650008 ;

--
-- Dumping data for table `mf_loan`
--

INSERT INTO `mf_loan` (`id`, `customer_id`, `lender_id`, `loan_amount`, `interest`, `start_date`, `end_date`, `daily_amount`, `days`, `payback_amount`, `balance_amount`, `status`) VALUES
(600000, 60000, 6, 1000, '20', '2015-04-17', '2015-05-12', 48, 25, 1200, 1200, 0),
(600001, 60000, 6, 2000, '20', '2015-04-17', '2015-07-14', 27, 88, 2400, 2400, 0),
(600003, 60000, 6, 213, '20', '2015-04-17', '2015-04-18', 256, 1, 256, 200, 0),
(600002, 60000, 6, 3000, '20', '2015-04-17', '2015-05-12', 144, 25, 3600, 3600, 0),
(640004, 60004, 6, 5680, '20', '2015-04-17', '2015-07-14', 77, 88, 6816, 5950, 0),
(620005, 60002, 6, 586328, '20', '2015-04-18', '2015-05-18', 23453, 30, 703594, 703594, 0),
(650006, 60005, 6, 40000, '20', '2015-04-20', '2015-04-24', 12000, 4, 48000, 35500, 0),
(650007, 660006, 66, 1000, '20', '2015-06-23', '2015-06-28', 240, 5, 1200, 960, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mf_payment`
--

CREATE TABLE IF NOT EXISTS `mf_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `collection_amount` int(11) NOT NULL,
  `remaining_amount` int(11) NOT NULL,
  `collection_date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=656004 ;

--
-- Dumping data for table `mf_payment`
--

INSERT INTO `mf_payment` (`id`, `loan_id`, `collection_amount`, `remaining_amount`, `collection_date`, `status`) VALUES
(644000, 640004, 816, 6000, '2015-04-19', 1),
(656001, 650006, 12000, 36000, '2015-04-20', 1),
(656002, 650006, 500, 35500, '2015-04-25', 1),
(603003, 600003, 56, 200, '2015-04-25', 1),
(644004, 640004, 50, 5950, '2015-04-25', 1),
(656003, 650007, 240, 960, '2015-06-23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mf_subscription_type`
--

CREATE TABLE IF NOT EXISTS `mf_subscription_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscription_name` varchar(400) NOT NULL,
  `sku_id` varchar(500) NOT NULL,
  `subscription_amount` varchar(400) NOT NULL,
  `subscription_details` varchar(400) NOT NULL,
  `status` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `mf_subscription_type`
--

INSERT INTO `mf_subscription_type` (`id`, `subscription_name`, `sku_id`, `subscription_amount`, `subscription_details`, `status`) VALUES
(1, '1 Month', 'month_subscription', '50PHP', '1 Month Subscription', 'Active'),
(2, '1 Year', 'one_year_subscription', '500PHP', '1 Year Subscription', 'Active'),
(4, '7 Days', 'future_plan1', '10PHP', '7 Days Subscription', 'Inactive'),
(5, '10 Days', 'future_plan2', '15PHP', '10 Days Subscription', 'Inactive');

-- --------------------------------------------------------

--
-- Table structure for table `mf_users`
--

CREATE TABLE IF NOT EXISTS `mf_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `mf_users`
--

INSERT INTO `mf_users` (`id`, `mobile`, `email`, `password`, `date`, `status`) VALUES
(6, '9178294450', 'hhh@123.com', '3b9a045e3ca88b055ec0248ddd7c0570', '2014-12-17', 1),
(37, '9273977661', 'kim16fatima@gmail.com', '89a12a04343877fcdcbb23f0238d3351', '2015-01-28', 1),
(4, '8050582590', 'sriharan40@gmail.com', 'd1565ebd8247bbb01472f80e24ad29b6', '2014-12-23', 1),
(36, '9255774448', 'mark.almayda81@gmail.com', '4d3bf76548167a1d28dbd269d0ce3c5a', '2015-01-28', 1),
(35, '9393551241', 'mark.almayda81@gmail.com', '4d3bf76548167a1d28dbd269d0ce3c5a', '2015-01-28', 1),
(30, '9173210480', 'jess.faller@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2015-01-06', 0),
(34, '9169256002', 'alanruswealthmercadoclamonte@gmail.com', 'dfc01b3eab5b37d0f77a2df06cde92c5', '2015-01-23', 1),
(12, '9196191150', 'cjwasu@gmail.com', '619ebc9aa644244397b2bdfb5953f3d8', '2014-12-26', 1),
(33, '9738426433', '', '006d2143154327a64d86a264aea225f3', '2015-01-15', 1),
(24, '9174259901', 'goodboy4447@gmail.com', '606e4497f197c260ba5f7a0fee46c521', '2014-12-31', 1),
(15, '9186498638', 'mango_mixy@yahoo.com', '2552f373637b503dafd1cc626d35d848', '2014-12-30', 1),
(38, '9173766027', 'brarneetu52@ymail.com', 'e9269342c94a9f3558b1f0785020ad88', '2015-02-01', 1),
(39, '9361187523', 'geemnegee@gmail.com', '2566ad4d85bb5bf0593a07231682f96b', '2015-02-03', 1),
(40, '9435557855', 'daphdaleasia@gmail.com', 'f9804b63a8be0d2e74bb0ccb2325a8bb', '2015-02-11', 1),
(45, '9052710271', 'mohitkalariya@gmail.com', 'd3ba4df544931b4a85256f459461c5b4', '2015-02-14', 1),
(46, '9276714330', 'ravikalariya1990@gmail.com', '6f074590554b21986ab7fc125bf5ad19', '2015-02-14', 1),
(43, '9267435576', 'manjit_009@yahoo.com', 'b8cff776095455e49b10bae12a69565d', '2015-02-12', 0),
(44, '9162685796', 'amaritsingh28@gmail.com', 'e99a18c428cb38d5f260853678922e03', '2015-02-12', 0),
(47, '9223145891', 'robajack9@yahoo.com', '6707e061aa34f3be594eb4667c3d5a0d', '2015-02-16', 0),
(48, '9223145819', 'robajack9@yahoo.com', '6707e061aa34f3be594eb4667c3d5a0d', '2015-02-16', 0),
(49, '9223145819', 'robajack9@yahoo.com', '6707e061aa34f3be594eb4667c3d5a0d', '2015-02-16', 0),
(50, '9162685796', 'amaritsingh28@gmail.com', 'e99a18c428cb38d5f260853678922e03', '2015-02-18', 1),
(51, '9223145819', 'robjack9@yahoo.com', '6707e061aa34f3be594eb4667c3d5a0d', '2015-02-19', 1),
(52, '9236323407', 'singhbrar222@gmail.com', 'b43517c234601713b5661b17a4651b72', '2015-02-21', 1),
(53, '9236323407', 'jaswantbrar222@yahoo.com', '94015f84a81020cd6ad3e23a67b3f2a3', '2015-02-21', 1),
(54, '9236323407', 'singhbrar222@gmail.com', 'b43517c234601713b5661b17a4651b72', '2015-02-21', 0),
(55, '9398812230', 'cars_trend@ymail.com', 'e5a0eaa5029d1b9c470761f89416e265', '2015-02-25', 0),
(56, '9398812230', 'cars_trend@ymail.com', 'e5a0eaa5029d1b9c470761f89416e265', '2015-02-25', 0),
(57, '9178618819', 'karanzsidhu83@gmail.com', '23355a7a2af6afca6cc8050ef4f2587a', '2015-02-28', 1),
(58, '9159407343', 'captainsingh_40@yahoo.com', '40f283caacb11de495a8725fa80e6f77', '2015-03-02', 1),
(59, '9178840249', 'tony_@yahoo.com', '5c223bb5ce87953bff76b98e457f9ccd', '2015-03-13', 0),
(60, '9292998666', 'prince_pcs@yahoo.com', 'c7dfe43deaf1e49c668c66ccb68ab855', '2015-03-16', 0),
(61, '9369652666', 'prince_pcs@yahoo.com', 'c7dfe43deaf1e49c668c66ccb68ab855', '2015-03-16', 1),
(62, '9178050070', 'isidro.mark@yahoo.com', '8eba0d45193a619a35e0ec2a2ea6c2e5', '2015-03-17', 0),
(63, '9178050070', 'isidro.mark@yahoo.com', '8eba0d45193a619a35e0ec2a2ea6c2e5', '2015-03-17', 0),
(64, '9487383158', 'sriharan40@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '2015-04-02', 1),
(65, '9535883213', 'saravanarajan.ms@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '2015-04-25', 0),
(66, '9620150500', 'sriharan40@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '2015-06-23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mf_user_subscription`
--

CREATE TABLE IF NOT EXISTS `mf_user_subscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(400) NOT NULL,
  `subscription_type` varchar(400) NOT NULL,
  `subscription_start_from` varchar(400) NOT NULL,
  `subscription_end_on` varchar(400) NOT NULL,
  `subscription_updated_on` varchar(400) NOT NULL,
  `status` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `mf_user_subscription`
--

INSERT INTO `mf_user_subscription` (`id`, `user_id`, `subscription_type`, `subscription_start_from`, `subscription_end_on`, `subscription_updated_on`, `status`) VALUES
(46, '45', '', '2015-02-14 18:45:37', '2015-02-21 18:45:37', '', '1'),
(45, '44', '', '2015-02-12 15:11:46', '2015-02-19 15:11:46', '', '1'),
(4, '4', '', '2014-12-23 17:32:51', '2015-03-30 09:58:24', '', '1'),
(6, '6', '1', '2014-12-17 09:58:24', '2015-05-30 09:58:24', '2014-12-27 15:11:27', '1'),
(36, '35', '', '2015-01-28 00:00:04', '2015-03-04 00:00:04', '', '1'),
(34, '33', '', '2015-01-15 14:40:52', '2015-02-22 14:40:52', '', '1'),
(35, '34', '', '2015-01-23 08:17:42', '2015-03-23 08:17:42', '', '1'),
(12, '12', '', '2014-12-26 21:05:28', '2016-03-30 09:58:24', '', '1'),
(44, '43', '', '2015-02-12 12:14:01', '2015-02-19 12:14:01', '', '1'),
(43, '42', '', '2015-02-12 12:13:21', '2015-02-19 12:13:21', '', '1'),
(42, '41', '', '2015-02-12 12:11:49', '2015-02-19 12:11:49', '', '1'),
(41, '40', '', '2015-02-11 20:07:50', '2015-02-18 20:07:50', '', '1'),
(16, '15', '', '2014-12-30 19:24:48', '2015-03-30 09:58:24', '', '1'),
(40, '39', '', '2015-02-03 12:20:36', '2015-02-10 12:20:36', '', '1'),
(39, '38', '', '2015-02-01 19:10:06', '2015-03-08 19:10:06', '', '1'),
(38, '37', '', '2015-01-28 21:47:18', '2015-03-04 21:47:18', '', '1'),
(30, '30', '', '2015-01-06 02:45:04', '2015-03-30 09:58:24', '', '1'),
(32, '31', '', '2015-01-15 14:35:54', '2015-03-22 14:35:54', '', '1'),
(33, '31', '', '2015-01-15 14:36:06', '2015-03-22 14:36:06', '', '1'),
(37, '36', '', '2015-01-28 12:10:50', '2015-03-04 12:10:50', '', '1'),
(25, '24', '', '2014-12-31 14:36:18', '2015-03-30 09:58:24', '', '1'),
(47, '46', '', '2015-02-14 20:40:57', '2015-02-21 20:40:57', '', '1'),
(48, '47', '', '2015-02-16 13:59:51', '2015-02-23 13:59:51', '', '1'),
(49, '48', '', '2015-02-16 14:00:42', '2015-02-23 14:00:42', '', '1'),
(50, '49', '', '2015-02-16 14:01:35', '2015-02-23 14:01:35', '', '1'),
(51, '50', '', '2015-02-18 10:41:52', '2015-02-25 10:41:52', '', '1'),
(52, '51', '', '2015-02-19 10:43:59', '2015-02-26 10:43:59', '', '1'),
(53, '52', '', '2015-02-21 12:01:28', '2015-02-28 12:01:28', '', '1'),
(54, '53', '', '2015-02-21 12:38:59', '2015-02-28 12:38:59', '', '1'),
(55, '54', '', '2015-02-21 16:05:42', '2015-02-28 16:05:42', '', '1'),
(56, '55', '', '2015-02-25 13:46:36', '2015-03-04 13:46:36', '', '1'),
(57, '56', '', '2015-02-25 18:53:36', '2015-03-04 18:53:36', '', '1'),
(58, '57', '', '2015-02-28 15:18:36', '2015-03-07 15:18:36', '', '1'),
(59, '58', '', '2015-03-02 19:08:42', '2015-03-09 19:08:42', '', '1'),
(60, '59', '', '2015-03-13 11:25:41', '2015-03-20 11:25:41', '', '1'),
(61, '60', '', '2015-03-16 19:21:12', '2015-03-23 19:21:12', '', '1'),
(62, '61', '', '2015-03-16 19:23:02', '2015-03-23 19:23:02', '', '1'),
(63, '62', '', '2015-03-17 20:44:14', '2015-03-24 20:44:14', '', '1'),
(64, '63', '', '2015-03-17 20:46:30', '2015-03-24 20:46:30', '', '1'),
(65, '64', '', '2015-04-02 22:47:51', '2015-05-09 22:47:51', '', '1'),
(66, '65', '', '2015-04-25 12:02:14', '2015-05-02 12:02:14', '', '1'),
(67, '66', '', '2015-06-23 15:39:20', '2015-06-30 15:39:20', '', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
