-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 27, 2015 at 11:49 AM
-- Server version: 5.5.44-37.3-log
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `renteasy_microfinance`
--

-- --------------------------------------------------------

--
-- Table structure for table `mf_sales_activations`
--

CREATE TABLE IF NOT EXISTS `mf_sales_activations` (
  `SalesmanId` int(11) NOT NULL COMMENT 'sameasAutoId in mf auth sales table',
  `PhoneActivated` int(11) NOT NULL,
  `PaymentReceived` int(11) NOT NULL,
  `DateOfAct` date NOT NULL,
  PRIMARY KEY (`SalesmanId`,`PhoneActivated`,`DateOfAct`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
