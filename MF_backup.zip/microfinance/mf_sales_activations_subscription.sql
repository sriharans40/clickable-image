-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2015 at 05:05 AM
-- Server version: 5.6.25
-- PHP Version: 5.5.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `microfinance`
--

-- --------------------------------------------------------

--
-- Table structure for table `mf_sales_activations_subscription`
--

CREATE TABLE IF NOT EXISTS `mf_sales_activations_subscription` (
  `subscription_id` int(11) NOT NULL,
  `subscription_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mf_sales_activations_subscription`
--

INSERT INTO `mf_sales_activations_subscription` (`subscription_id`, `subscription_name`) VALUES
(1, '3 Month'),
(2, '6 Month'),
(3, '12 Month');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mf_sales_activations_subscription`
--
ALTER TABLE `mf_sales_activations_subscription`
  ADD PRIMARY KEY (`subscription_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
